const API_URL = "http://localhost:3001/api/";

export { API_URL };